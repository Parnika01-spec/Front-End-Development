// ===== NAVIGATION TOGGLE =====
const navLinks = document.getElementById("navLinks");
function showMenu() {
  navLinks.style.right = "0";
}
function hideMenu() {
  navLinks.style.right = "-200px";
}

// ===== PAGE FADE-IN =====
window.addEventListener("load", () => {
  document.querySelector(".page-wrapper").classList.add("visible");
});

// ===== SCROLL REVEAL ANIMATIONS =====
ScrollReveal({
  reset: true,
  distance: "60px",
  duration: 1500,
  delay: 200,
});

ScrollReveal().reveal(".text-box h1, .hero-btn", {
  delay: 200,
  origin: "bottom",
});
ScrollReveal().reveal(".about h1, .about p", { delay: 200, origin: "top" });
ScrollReveal().reveal(".about-col, .course-col, .blog-card, .gallery-item", {
  delay: 300,
  origin: "bottom",
  interval: 100,
});
ScrollReveal().reveal(".contact h1, .contact p, .contact a", {
  delay: 200,
  origin: "bottom",
});

// ===== LIGHTBOX =====
const lightbox = document.getElementById("lightbox");
const lightboxImage = document.querySelector(".lightbox-image");
const closeBtn = document.querySelector(".lightbox .close");
const prevBtn = document.querySelector(".lightbox .prev");
const nextBtn = document.querySelector(".lightbox .next");
const galleryImages = Array.from(document.querySelectorAll(".gallery-item img"));
let currentIndex = 0;
let autoSlideInterval = null;

galleryImages.forEach((img, index) => {
  img.addEventListener("click", () => openLightbox(index));
});

function openLightbox(index) {
  lightbox.classList.add("show");
  lightboxImage.src = galleryImages[index].src;
  currentIndex = index;
  startAutoSlide();
}
function closeLightbox() {
  lightbox.classList.remove("show");
  stopAutoSlide();
}
closeBtn.addEventListener("click", closeLightbox);
nextBtn.addEventListener("click", () => {
  currentIndex = (currentIndex + 1) % galleryImages.length;
  lightboxImage.src = galleryImages[currentIndex].src;
  resetAutoSlide();
});
prevBtn.addEventListener("click", () => {
  currentIndex = (currentIndex - 1 + galleryImages.length) % galleryImages.length;
  lightboxImage.src = galleryImages[currentIndex].src;
  resetAutoSlide();
});
lightbox.addEventListener("click", (e) => {
  if (e.target === lightbox) closeLightbox();
});
window.addEventListener("keydown", (e) => {
  if (e.key === "Escape") closeLightbox();
});

// ===== AUTO SLIDESHOW =====
function startAutoSlide() {
  stopAutoSlide();
  autoSlideInterval = setInterval(() => {
    currentIndex = (currentIndex + 1) % galleryImages.length;
    lightboxImage.src = galleryImages[currentIndex].src;
  }, 4000);
}
function stopAutoSlide() {
  if (autoSlideInterval) clearInterval(autoSlideInterval);
  autoSlideInterval = null;
}
function resetAutoSlide() {
  stopAutoSlide();
  startAutoSlide();
}
